# AQS Italia - Gestione Commesse

## Setup
```
npm install
npm run dev       # sviluppo locale
npm run build     # compila per produzione
```

## Deploy
Carica la cartella dist/ su Netlify o Vercel (gratuiti).

## Credenziali
- Admin: admin / admin2026
- Dipendenti: cinzia, nicole, silvia, massimo, giuseppe, desena (password: nome+2026)
